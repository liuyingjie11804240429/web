package keshe;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

/**
 * ���ɵ����浥ͼƬ����
 * @author wu
 * @version 1.0
 * @time 2017/04/25
 * */
public class SFOrderGenerateUtil {

     private static final Logger logger = Logger.getLogger(SFOrderGenerateUtil.class.getSimpleName());

     //ͼƬ�Ŀ���
     public static final int IMG_WIDTH = 1198;
     //ͼƬ�Ŀ���
     public static final int IMG_HEIGHT = 1800;
     //LOGO�Ŀ���
     public static final int LOGO_WIDTH = 240;
     //LOGO�߶�
     public static final int LOGO_HEIGHT = 100;
     //LOGO�ͷ��绰�Ŀ���
     public static final int LOGO_TEL_WIDTH = 220;
     //LOGO�ͷ��绰�߶�
     public static final int LOGO_TEL_HEIGHT = 84;

     //Logo·��
     public static final String LOGO_PATH = "D:\\COD\\timg.jpg";
     //Logo�ͷ��绰
     public static final String LOGO_TEL_PATH = "D:\\COD\\111.jpg";;


     public static BufferedImage image;
     public static void createImage(String fileLocation) {
         FileOutputStream fos = null;
         BufferedOutputStream bos = null;
         try {
              fos = new FileOutputStream(fileLocation);
              bos = new BufferedOutputStream(fos);
              JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(bos);
              encoder.encode(image);
         } catch (Exception e) {
               e.printStackTrace();
         } finally {
             try {
                 if (bos != null) bos.close();
                 if (fos != null) fos.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
         }
    }

     /**
      * ���ɶ���ͼƬ
      * @param orderPath
      *                 ���ɶ������·��
      * @param printTyp
      *                 ������ӡ���� 1:A4ֽ��ӡ   2:����ֽ��ӡ
      * @param orderParam
      *                 ���ɶ�������Ĳ�������
      * @param isCompress
      *                 �Ƿ���Ҫ�����������ѹ��ͼƬ
      * <pre>
      *        isCompress Ϊtureʱ ������Ŀ��߲�������
      * </pre>
      * @param imgWidth
      *                ͼƬ����
      * @param imgHeidht
      *                ͼƬ�߶�
      * @author Administrator
      * @return
      *
      * */
    public static boolean generateOrders(String orderPath, SfPrintOrderParam orderParam, String printTyp, boolean isCompress, int imgWidth, int imgHeidht){
        if (null == orderParam)
            return false;
        int startHeight = 0;  //�������ʼ�߶�
        int startWidth = 0;   //�������ʼ����
        try {
            if (orderParam.getSubMailNos().size() == 0 || orderParam.getSubMailNos().isEmpty()) {
                generateParentOrder(orderPath, orderParam, printTyp, isCompress, imgWidth, imgHeidht);
                return true;
            } else {
                String picPath = orderPath;
                File mk = new File(picPath + orderParam.getMailNo());
                if (mk.exists()){
                    FileUtils.deleteDirectory(mk);
                }
                for (int k = 0; k < orderParam.getSubMailNos().size(); k++) {
                    image = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_RGB);
                    Graphics2D g = image.createGraphics();
                    //���˵���Ϊ���ƴ�����Ŷ�����Ŀ¼
                    FileUtils.forceMkdir(mk);
                    picPath += orderParam.getMailNo() + "/";

                    //���ñ���ɫΪ��ɫ
                    g.setColor(Color.WHITE);
                    //������ɫ�����С
                    g.fillRect(0, 0, IMG_WIDTH, IMG_HEIGHT);
                    //��ߵ���Img��������


                    /*
                     * ���Ʊ��� �������
                     * */
                    //������������ɫ
                    g.setColor(Color.BLACK);

                    //�����ı����־������
                    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    //g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_GASP);

                    //������ĸ��߿�
                    g.drawLine(startWidth, startHeight, startWidth + 374, startHeight); //�ϱ߿�
                    g.drawLine(startWidth, startHeight, startWidth, startHeight + 562); //��߿�
                    g.drawLine(startWidth, startHeight + 562, startWidth + 375, startHeight + 562); //�±߿�
                    g.drawLine(startWidth + 374, startHeight, startWidth + 374, startHeight + 563); //�ұ߿�

                    //���Ʊ������� ��һ��
                    g.drawLine(startWidth, startHeight + 48, startWidth + 375, startHeight + 48);

                    //�����ϴ�����Logo
                    Image logoImg = insertImage(LOGO_PATH, LOGO_WIDTH, LOGO_HEIGHT, true);
                    g.drawImage(logoImg, startWidth + 4, startHeight + 8, null);
                    //����ڶ���logo 
                    Image logoTelImg = insertImage(LOGO_TEL_PATH, LOGO_TEL_WIDTH, LOGO_TEL_HEIGHT, true);
                    g.drawImage(logoTelImg, startWidth + 280, startHeight + 15, null);

                    //��д��Ʒ����
                    Font fontSfTyp = new Font("����", Font.BOLD, 36);
                    g.setFont(fontSfTyp);
                    //��Ʒ�����ַ���
                    String sfProTypStr = orderParam.getEarthCarryFlag();
                    g.drawString(sfProTypStr, startWidth + 150, startHeight + 41);

                    //���Ƶڶ���
                    g.drawLine(startWidth, startHeight + 124, startWidth + 375, startHeight + 124);
                    g.drawLine(startWidth + 276, startHeight + 48, startWidth + 276, startHeight + 124);

                    //����code128c ����
                    SFBarCodeGenerateUtil.generateBarCode(orderParam.getMailNo(),          //�˵���
                             picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg",           //ͼƬ����
                             262,                                   //ͼƬ����
                             45,                                    //ͼƬ�߶�
                             SFBarCodeGenerateUtil.PICTURE_JPG);
                    //��������ͼƬ
                    Image sfBarImg = insertImage(picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg", 0, 0, false);
                    g.drawImage(sfBarImg, startWidth + 7, startHeight + 53, null);
                    sfBarImg.flush();

                    //��������
                    Font fontSfBarCode = new Font("����",Font.BOLD,10);
                    g.setFont(fontSfBarCode);

                    String pageNum = (k + 1) + "/" + orderParam.getSubMailNos().size();
                     g.drawString(pageNum, startWidth + 7, startHeight + 108);

                    //�ӵ���
                    String subBarCodeStr = orderParam.getSubMailNos().get(k);
                    subBarCodeStr = subBarCodeStr.replaceAll("(.{3})", "$1 ");
                    g.drawString("�ӵ���  " + subBarCodeStr, startWidth + 80, startHeight + 108);

                    //�����ַ���������ĸ���ţ�
                    String sfBarCodeStr = orderParam.getMailNo();
                    sfBarCodeStr = sfBarCodeStr.replaceAll("(.{3})", "$1 ");
                    g.drawString("ĸ����  " + sfBarCodeStr, startWidth + 80, startHeight + 120);

                    //���Ʋ�Ʒ���Ϳ�
                    g.drawLine(startWidth + 276, startHeight + 70, startWidth + 375, startHeight + 70);
                    Font fontSfProtypSub = new Font("����", Font.BOLD, 14);
                    g.setFont(fontSfProtypSub);

                    //��Ʒ�����ַ���
                    String subSfProTypStr = orderParam.getExpressTyp();
                    g.drawString(subSfProTypStr, startWidth + 295, startHeight + 65);

                    //Ŀ�ĵ����Ļ���
                    g.drawLine(startWidth, startHeight + 176, startWidth + 375, startHeight + 176);
                    g.drawLine(startWidth + 21, startHeight + 124, startWidth + 21, startHeight + 176);

                    //Ŀ�ĵ���д
                    Font fontDest = new Font("����", Font.BOLD, 10);
                    g.setFont(fontDest);
                    //Ŀ�ĵر���
                    String destTitleStr = "Ŀ�ĵ�";
                    char[] destTitleArray = destTitleStr.toCharArray();
                    int destTitleWidth = startWidth + 6;
                    int destTitleHeight = startHeight + 140;
                    for (int i = 0; i < destTitleStr.length(); i++) {
                        g.drawString(String.valueOf(destTitleArray[i]), destTitleWidth, destTitleHeight);
                        destTitleHeight += 12;
                    }

                    //Ŀ�ĵش���
                    Font fontDestCode = new Font("Arial", Font.BOLD, 36);
                    g.setFont(fontDestCode);
                    //Ŀ�ĵش����ַ���
                    String destCode = orderParam.getDestCode();
                    g.drawString(destCode, startWidth + 24, startHeight + 165);

                    //�ռ��˱�����
                    g.drawLine(startWidth, startHeight + 225, startWidth + 1198, startHeight + 225);
                    g.drawLine(startWidth + 21, startHeight + 176, startWidth + 21, startHeight + 225);

                    //�����ռ��˱�������
                    Font fontRevicer = new Font("����", Font.BOLD, 10);
                    g.setFont(fontRevicer);
                    //�ռ��˱����ַ���
                    String revicerTitleStr = "�ռ���";
                    char[] revicerTitleArray = revicerTitleStr.toCharArray();
                    int revicerTitleWidth = startWidth + 6;
                    int revicerTitleHeight = startHeight + 192;
                    for (int i = 0; i < revicerTitleStr.length(); i++) {
                        g.drawString(String.valueOf(revicerTitleArray[i]), revicerTitleWidth, revicerTitleHeight);
                        revicerTitleHeight += 11;
                    }

                    /*
                     * �ռ�����ϸ��Ϣ
                     * */
                    String dContact = orderParam.getdContact(); //�ռ�������
                    String dTel = orderParam.getdTel(); //��ϵ�绰
                    String dMoblie = orderParam.getdMobile(); //��ϵ���ֻ���
                    String dCompany = orderParam.getdCompany(); //��˾����
                    String dProvince = orderParam.getdProvince();
                    String dCity = orderParam.getdCity();
                    String dCounty = orderParam.getdCounty();
                    String dAddress = orderParam.getdAddress(); //��ϸ��ַ

                    String revicerInfo = dContact + " " + dTel + " " + dMoblie + "" + dCompany;
                    dAddress = dProvince + dCity + dCounty + dAddress;

                    //�����ռ�����Ϣ����
                    Font fontRevicerInfo = new Font("����", Font.BOLD, 14);
                    g.setFont(fontRevicerInfo);
                    g.drawString(revicerInfo, startWidth + 24, startHeight + 190);
                    //�����ռ�����ϸ��ַ����
                    Font fontReviceAddress = new Font("����", Font.BOLD, 14);
                    g.setFont(fontReviceAddress);
                    if (dAddress.length() > 23) {
                       g.drawString(dAddress.substring(0, 23), startWidth + 24, startHeight + 205);
                       g.drawString(dAddress.substring(23, dAddress.length()), startWidth + 24, startHeight + 220);
                    } else {
                       g.drawString(dAddress, startWidth + 24, startHeight + 205);
                    }

                    //���Ƽļ��˱���
                    g.drawLine(startWidth, startHeight + 259, startWidth + 375, startHeight +259);
                    g.drawLine(startWidth + 21, startHeight + 225, startWidth + 21, startHeight + 259);

                    //���üļ��˱�������
                    Font fontSender = new Font("����", Font.BOLD, 10);
                    g.setFont(fontSender);
                    //�ļ��˱����ַ���
                    String senderTitleStr = "�ļ���";
                    char[] senderTitleArray = senderTitleStr.toCharArray();
                    int senderTitleWidth = startWidth + 6;
                    int senderTitleHeight = startHeight + 235;
                    for (int i = 0; i < senderTitleStr.length(); i++) {
                        g.drawString(String.valueOf(senderTitleArray[i]), senderTitleWidth, senderTitleHeight);
                        senderTitleHeight += 11;
                    }


                    /*
                     * �ļ�����Ϣ
                     * **/
                    String jContact = orderParam.getjContact(); //�ļ�������
                    String jTel = orderParam.getjTel(); //�ļ�����ϵ�绰
                    String jMobile = orderParam.getjMobile();
                    String jCompany = orderParam.getjCompany();
                    String jProvince = orderParam.getjProvince();
                    String jCity = orderParam.getjCity();
                    String jCounty = orderParam.getjCounty();
                    String jAddress = orderParam.getjAddress();

                    String senderInfo = jContact + " " + jTel + " " + jMobile + " " + jCompany;
                    jAddress = jProvince + jCity + jCounty + jAddress;

                    //���üļ�����Ϣ����
                    Font fontSenderInfo = new Font("����", Font.PLAIN, 8);
                    g.setFont(fontSenderInfo);
                    g.drawString(senderInfo, startWidth + 24, startHeight + 240);

                    //���üļ�����ϸ��ַ����
                    Font fontSenderAddress = new Font("����", Font.PLAIN, 8);
                    g.setFont(fontSenderAddress);
                    if (jAddress.length() > 27) {
                       g.drawString(jAddress.substring(0, 27), startWidth + 24, startHeight + 250);
                       g.drawString(jAddress.substring(27, jAddress.length()), startWidth + 24, startHeight + 265);
                    } else {
                       g.drawString(jAddress, startWidth + 24, startHeight + 250);
                    }

                    //�������ͷ�ʽ����
                    g.drawLine(startWidth + 310, startHeight + 225, startWidth + 310, startHeight + 338);
                    //����������������
                    Font fontSenTyp = new Font("����", Font.BOLD, 55);
                    g.setFont(fontSenTyp);

                    //�����ϸ��Ϣ����
                    g.drawLine(startWidth, startHeight + 304, startWidth + 310, startHeight + 304);

                    //�����ϸ��Ϣ
                    Font cellFont = new Font("����", Font.PLAIN, 9);
                    g.setFont(cellFont);
                    String[][] cellValue1 = {
                            {"���ʽ��",orderParam.getPayMethod()},
                            {"�½��˺ţ�",orderParam.getMonthSettleNo()},
                            {"������������",orderParam.getThridArea()},
                            {"ʵ��������",orderParam.getRealWeight()}
                    };
                    int cellLineHeight = startHeight + 268;
                    for (int i = 0; i < cellValue1.length; i++) {
                        g.drawString(cellValue1[i][0], startWidth + 3, cellLineHeight);
                        g.drawString(cellValue1[i][1], startWidth + 52, cellLineHeight);
                        cellLineHeight += 10;
                    }
                    String[][] cellValue2 = {
                            {"�Ʒ�������",orderParam.getChargWeight()},
                            {"������ֵ��",orderParam.getDeclarPrice()},
                            {"���۷��ã�",orderParam.getSupportFee()},
                            {"��ʱ���ͣ�",orderParam.getSendTime()}
                    };
                    cellLineHeight = startHeight + 268;
                    for (int i = 0; i < cellValue2.length; i++) {
                        g.drawString(cellValue2[i][0], startWidth + 100, cellLineHeight);
                        g.drawString(cellValue2[i][1], startWidth + 150, cellLineHeight);
                        cellLineHeight += 10;
                    }
                    String[][] cellValue3 = {
                            {"��װ���ã�",orderParam.getPackFee()},
                            {"�˷ѣ�",orderParam.getFreight()},
                            {"���úϼƣ�",orderParam.getSumFee()}
                    };
                    cellLineHeight = startHeight + 268;
                    for (int i = 0; i < cellValue3.length; i++) {
                        g.drawString(cellValue3[i][0], startWidth + 220, cellLineHeight);
                        g.drawString(cellValue3[i][1], startWidth + 270, cellLineHeight);
                        cellLineHeight += 10;
                    }

                    //ת��Э��ͻ�
                    Font fowardFont = new Font("����", Font.BOLD, 9);
                    g.setFont(fowardFont);
                    String fowardStr = "ת��Э��ͻ�";
                    g.drawString(fowardStr, startWidth + 250, startHeight + 302);

                    //�м���
                    g.drawLine(startWidth + 21, startHeight + 304, startWidth + 21, startHeight + 338);
                    //�м�������ַ���
                    String articleTitleStr = "�м���";
                    char[] articleTitleArray = articleTitleStr.toCharArray();
                    int articleTitleWidth = startWidth + 6;
                    int articleTitleHeight = startHeight + 315;
                    for (int i = 0; i < articleTitleStr.length(); i++) {
                        g.drawString(String.valueOf(articleTitleArray[i]), articleTitleWidth, articleTitleHeight);
                        articleTitleHeight += 10;
                    }

                    Font cargoFont = new Font("����", Font.PLAIN, 8);
                    g.setFont(cargoFont);
                    String cargoContent = orderParam.getCargoContent();
                    g.drawString(cargoContent, startWidth + 24, 315);

                    //�ռ�Ա��Ϣ
                    g.drawLine(startWidth + 220, startHeight + 304, startWidth + 220, startHeight + 338);
                    Font receDriverFont = new Font("����", Font.PLAIN, 8);
                    g.setFont(receDriverFont);
                    String[][] receDriverStrs = {
                            {"�ռ�Ա��",orderParam.getReviceDriver()},
                            {"�ļ����ڣ�",orderParam.getSendDate()},
                            {"�ɼ�Ա��",orderParam.getSendDriver()}
                    };
                    cellLineHeight = startHeight + 315;
                    for (int i = 0; i < receDriverStrs.length; i++) {
                        g.drawString(receDriverStrs[i][0], startWidth + 225, cellLineHeight);
                        g.drawString(receDriverStrs[i][1], startWidth + 265, cellLineHeight);
                        cellLineHeight += 10;
                    }
                    //ǩ��
                    String signStr = "ǩ����";
                    g.drawString(signStr, startWidth + 312, startHeight + 268);
                    //����
                    String monthDay = "��   ��";
                    g.drawString(monthDay, startWidth + 345, startHeight + 336);

                    //ĸ�����ӵ��ָ���
                    g.drawLine(startWidth, startHeight + 338, startWidth + 375, startHeight + 338);

                    //--------------------------- ������ӵ��� �����ӵ���Ϣ ----------------------------------//
                    g.drawLine(startWidth, startHeight + 394, startWidth + 375, startHeight + 394);
                    g.drawLine(startWidth + 100, startHeight + 338, startWidth + 100, startHeight + 394);
                    //����Logo
                    Image sublogoImg = insertImage(LOGO_PATH, LOGO_WIDTH, LOGO_HEIGHT, true);
                    g.drawImage(sublogoImg, startWidth + 10, startHeight + 338, null);
                    //����ڶ���logo (�ͷ��绰)
                    Image sublogoTelImg = insertImage(LOGO_TEL_PATH, LOGO_TEL_WIDTH, LOGO_TEL_HEIGHT, true);
                    g.drawImage(sublogoTelImg, startWidth + 15, startHeight + 368, null);

                    //�����ӵ�����
                    //����code128c ����
                    SFBarCodeGenerateUtil.generateBarCode(orderParam.getSubMailNos().get(k),          //�˵���
                             picPath + "SFBarCoding_sub_" + orderParam.getSubMailNos().get(k) + ".jpg",           //ͼƬ����
                             169,                                   //ͼƬ����
                             37,                                    //ͼƬ�߶�
                             SFBarCodeGenerateUtil.PICTURE_JPG);
                    Image sfSubBarImg = insertImage(picPath + "SFBarCoding_sub_" + orderParam.getSubMailNos().get(k) + ".jpg", 0, 0, false);
                    g.drawImage(sfSubBarImg, startWidth + 150, startHeight + 342, null);
                    sfSubBarImg.flush();

                    //�ӵ���
                    Font subOrderFont = new Font("����", Font.BOLD, 10);
                    g.setFont(subOrderFont);
                    g.drawString("�ӵ��ţ� " + subBarCodeStr, startWidth + 160, startHeight + 390);

                    //���Ƽļ��˱��� �ӵ�
                    g.drawLine(startWidth, startHeight + 431, startWidth + 375, startHeight + 431);
                    g.drawLine(startWidth + 21, startHeight + 394, startWidth + 21, startHeight + 431);
                    //���üļ��˱�������
                    Font fontsubSender = new Font("����", Font.BOLD, 10);
                    g.setFont(fontsubSender);
                    //�ļ��˱����ַ���
                    String senderSubTitleStr = "�ļ���";
                    char[] senderSubTitleArray = senderSubTitleStr.toCharArray();
                    int senderSubTitleWidth = startWidth + 6;
                    int senderSubTitleHeight = startHeight + 408;
                    for (int i = 0; i < senderSubTitleStr.length(); i++) {
                        g.drawString(String.valueOf(senderSubTitleArray[i]), senderSubTitleWidth, senderSubTitleHeight);
                        senderSubTitleHeight += 10;
                    }
                    Font subJInfoFont = new Font("����", Font.PLAIN, 8);
                    g.setFont(subJInfoFont);
                    g.drawString(senderInfo, startWidth + 24, startHeight + 405);

                    if (jAddress.length() > 30) {
                      g.drawString(jAddress.substring(0, 30), startWidth + 24, startHeight + 415);
                      g.drawString(jAddress.substring(30, jAddress.length()), startWidth + 24, startHeight + 425);
                    } else {
                      g.drawString(jAddress, startWidth + 24, startHeight + 415);
                    }

                    //�����ռ��˱��� �ӵ�
                    g.drawLine(startWidth, startHeight + 469, startWidth + 375, startHeight + 469);
                    g.drawLine(startWidth + 21, startHeight + 394, startWidth + 21, startHeight + 469);
                    //�ռ��˱����ַ���
                    Font fontsubReveicer = new Font("����", Font.BOLD, 10);
                    g.setFont(fontsubReveicer);
                    String revicerSubTitleStr = "�ռ���";
                    char[] revicerSubTitleArray = revicerSubTitleStr.toCharArray();
                    int revicerSubTitleWidth = startWidth + 6;
                    int revicerSubTitleHeight = startHeight + 445;
                    for (int i = 0; i < revicerSubTitleStr.length(); i++) {
                        g.drawString(String.valueOf(revicerSubTitleArray[i]), revicerSubTitleWidth, revicerSubTitleHeight);
                        revicerSubTitleHeight += 10;
                    }

                    Font subDInfoFont = new Font("����", Font.PLAIN, 8);
                    g.setFont(subDInfoFont);
                    g.drawString(revicerInfo, startWidth + 24, startHeight + 442);
                    if (dAddress.length() > 35) {
                       g.drawString(dAddress.substring(0, 35), startWidth + 24, startHeight + 452);
                       g.drawString(dAddress.substring(35, dAddress.length()), startWidth + 24, startHeight + 462);
                    } else {
                       g.drawString(dAddress, startWidth + 24, startHeight + 452);
                    }
                    createImage(picPath + "SfOrderImage_" + orderParam.getMailNo() + "_" + (k + 1) + ".jpg");
                    //�����Ҫ��Ҫ�����Զ���ߴ�ѹ��ͼƬ
                    if (isCompress) {
                        //ѹ��ͼƬ
                        compressImg(picPath + "SfOrderImage_" + orderParam.getMailNo() + "_" + (k + 1) + ".jpg", imgWidth, imgHeidht);
                    }
                    g.dispose();
                    File sfSubFile = new File(picPath + "SFBarCoding_sub_" + orderParam.getSubMailNos().get(k) + ".jpg");
                    if (sfSubFile.exists() && sfSubFile.isFile()) {
                        if (!sfSubFile.delete()){
                            logger.error("ɾ��" + picPath + "SFBarCoding_sub_" + orderParam.getSubMailNos().get(k) + ".jpg ʧ�ܣ�");
                        }
                    }
                    File sfbarFile = new File(picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg");
                    if (sfbarFile.exists() && sfbarFile.isFile()) {
                        if (!sfbarFile.delete()) {
                            logger.error("ɾ��" + picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg ʧ�ܣ�");
                        }
                    }
                    logger.error("�������ɳɹ�. " + picPath + "SfOrderImage_" + orderParam.getMailNo() + "_" + (k + 1) + ".jpg");
                    picPath = orderPath;
                }
            }
            return true;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * ����ͼƬ �Զ���ͼƬ�Ŀ���
     * @param imgPath
     *             ����ͼƬ��·��
     * @param imgWidth
     *             ����ͼƬ�Ŀ���
     * @param imgHeight
     *             ����ͼƬ�ĸ߶�
     * @param isCompress
     *             �Ƿ�����Ŀ��߶���ͼƬ�ĳߴ磬ֻ��Ϊtrueʱ ����Ŀ��Ⱥ͸߶Ȳ�������<br/>
     *             Ϊfalseʱ����Ŀ��߲������ã�������ͼƬ��Ĭ�ϳߴ�
     * @return
     * @throws Exception
     * */
    private static Image insertImage(String imgPath, int imgWidth, int imgHeight, boolean isCompress) throws Exception {
        File fileimage = new File(imgPath);
        Image src = ImageIO.read(fileimage);
        if (isCompress) {
            Image image = src.getScaledInstance(imgWidth, imgHeight, Image.SCALE_SMOOTH);
            return image;
        }
        return src;
    }

    /**
     * ����ĸ����
     * @param orderParam ���ɶ�������Ĳ�������
     * @return boolean
     * */
    private static boolean generateParentOrder(String orderPath, SfPrintOrderParam orderParam, String printTyp, boolean isCompress, int imgWidth, int imgHeidht){
        if (null == orderParam)
            return false;
        String picPath = orderPath;
        int startHeight = 0;  //�������ʼ�߶�
        int startWidth = 0;   //�������ʼ����
        try {
            if (orderParam.getSubMailNos().size() == 0 || orderParam.getSubMailNos().isEmpty()) {
                image = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = image.createGraphics();

                //���˵���Ϊ���ƴ�����Ŷ�����Ŀ¼
                File mk = new File(picPath + orderParam.getMailNo());
                if (mk.exists()) {
                    FileUtils.deleteDirectory(mk);
                }
                FileUtils.forceMkdir(mk);

                picPath += orderParam.getMailNo() + "/";

                //���ñ���ɫΪ��ɫ
                g.setColor(Color.WHITE);
                //������ɫ�����С
                g.fillRect(0, 0, IMG_WIDTH, IMG_HEIGHT);

                /*
                 * ���Ʊ��� �������
                 * */
                //������������ɫ
                g.setColor(Color.BLACK);
                //�߿�Ӵ�
                g.setStroke(new BasicStroke(2.0f));
                //�����ı����־������
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                //������ĸ��߿�
                g.drawLine(startWidth, startHeight, startWidth + 1198, startHeight); //�ϱ߿�

                g.drawLine(startWidth, startHeight, startWidth, startHeight + 1800); //��߿�
                g.drawLine(startWidth, startHeight + 1799, startWidth + 1198, startHeight + 1799); //�±߿�
                g.drawLine(startWidth + 1197, startHeight, startWidth + 1197, startHeight + 1800); //�ұ߿�

                //���Ʊ������� ��һ��
                g.drawLine(startWidth, startHeight + 155, startWidth + 1198, startHeight + 155);

                //A4ֽ��ӡ�ǲ���Logo
                if (Integer.valueOf(printTyp) == ExpressConstant.ORDER_PRINT_TYP_A4) {
                    //����Logo
                    Image logoImg = insertImage(LOGO_PATH, LOGO_WIDTH, LOGO_HEIGHT, true);
                    g.drawImage(logoImg, startWidth + 30, startHeight + 30, null);
                    //����ڶ���logo (�ͷ��绰)
                    Image logoTelImg = insertImage(LOGO_TEL_PATH, LOGO_TEL_WIDTH, LOGO_TEL_HEIGHT, true);
                    g.drawImage(logoTelImg, startWidth + 920, startHeight + 30, null);
                }

                //E·��ʶ
                Font fontSfTyp = new Font("΢���ź�", Font.BOLD, 145);
                g.setFont(fontSfTyp);
                //E·��ʶ
                String sfProTypStr = orderParam.getEarthCarryFlag();
                g.drawString(sfProTypStr, startWidth + 445, startHeight + 130);

                //���Ƶڶ���
                g.drawLine(startWidth, startHeight + 396, startWidth + 1198, startHeight + 396);
                g.drawLine(startWidth + 750, startHeight + 155, startWidth + 750, startHeight + 396);

                //����code128c ����
                SFBarCodeGenerateUtil.generateBarCode(orderParam.getMailNo(),          //�˵���
                        picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg",           //ͼƬ����
                         600,                                   //ͼƬ����
                         120,                                   //ͼƬ�߶�
                         SFBarCodeGenerateUtil.PICTURE_JPG);
                //��������ͼƬ
                Image sfBarImg = insertImage(picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg", 0, 0, false);
                g.drawImage(sfBarImg, startWidth + 80, startHeight + 191, null);

                //��������
                Font fontSfBarCode = new Font("����",Font.BOLD,35);
                g.setFont(fontSfBarCode);

                String sfBarCodeStr = orderParam.getMailNo();
                sfBarCodeStr = sfBarCodeStr.replaceAll("(.{3})", "$1 ");
                g.drawString("ĸ����  " + sfBarCodeStr, startWidth + 150, startHeight + 355);

                //���Ʋ�Ʒ���Ϳ�
                g.drawLine(startWidth + 750, startHeight + 240, startWidth + 1198, startHeight + 240);
                Font fontSfProtypSub = new Font("����", Font.BOLD, 50);
                g.setFont(fontSfProtypSub);

                  //��Ʒ�����ַ���
                String subSfProTypStr = orderParam.getExpressTyp();
                g.drawString(subSfProTypStr, startWidth + 850, startHeight + 220);

                //Ŀ�ĵ����Ļ���
                g.drawLine(startWidth, startHeight + 563, startWidth + 1198, startHeight + 563);
                g.drawLine(startWidth + 80, startHeight + 396, startWidth + 80, startHeight + 563);

                //Ŀ�ĵ���д
                Font fontDest = new Font("����", Font.BOLD, 30);
                g.setFont(fontDest);
                //Ŀ�ĵر���
                String destTitleStr = "Ŀ�ĵ�";
                char[] destTitleArray = destTitleStr.toCharArray();
                int destTitleWidth = startWidth + 40;
                int destTitleHeight = startHeight + 460;
                for (int i = 0; i < destTitleStr.length(); i++) {
                    g.drawString(String.valueOf(destTitleArray[i]), destTitleWidth, destTitleHeight);
                    destTitleHeight += 33;
                }

                //Ŀ�ĵش���
                Font fontDestCode = new Font("Arial", Font.BOLD, 214);
                g.setFont(fontDestCode);
                //Ŀ�ĵش����ַ���
                String destCode = orderParam.getDestCode() == null ? "" : orderParam.getDestCode();
                g.drawString(destCode, startWidth + 90, startHeight + 555);

                //�ռ��˱�����
                g.drawLine(startWidth, startHeight + 720, startWidth + 1198, startHeight + 720);
                g.drawLine(startWidth + 80, startHeight + 563, startWidth + 80, startHeight + 720);

                //�����ռ��˱�������
                Font fontRevicer = new Font("����", Font.BOLD, 25);
                g.setFont(fontRevicer);
                //�ռ��˱����ַ���
                String revicerTitleStr = "�ռ���";
                char[] revicerTitleArray = revicerTitleStr.toCharArray();
                int revicerTitleWidth = startWidth + 40;
                int revicerTitleHeight = startHeight + 620;
                for (int i = 0; i < revicerTitleStr.length(); i++) {
                    g.drawString(String.valueOf(revicerTitleArray[i]), revicerTitleWidth, revicerTitleHeight);
                    revicerTitleHeight += 31;
                }

                /*
                 * �ռ�����ϸ��Ϣ
                 * */
                String dContact = orderParam.getdContact(); //�ռ�������
                String dTel = orderParam.getdTel(); //��ϵ�绰
                String dMoblie = orderParam.getdMobile(); //��ϵ���ֻ���
                String dCompany = orderParam.getdCompany(); //��˾����
                String dProvince = orderParam.getdProvince();
                String dCity = orderParam.getdCity();
                String dCounty = orderParam.getdCounty();
                String dAddress = orderParam.getdAddress(); //��ϸ��ַ

                String revicerInfo = dContact + " " + dTel + " " + dMoblie + " " + dCompany;
                dAddress = dProvince + dCity + dCounty + dAddress;

                //�����ռ�����Ϣ����
                Font fontRevicerInfo = new Font("����", Font.BOLD, 35);
                g.setFont(fontRevicerInfo);
                g.drawString(revicerInfo, startWidth + 90, startHeight + 610);
                //�����ռ�����ϸ��ַ����
                Font fontReviceAddress = new Font("����", Font.BOLD, 40);
                g.setFont(fontReviceAddress);
                if (dAddress.length() > 30) {
                   g.drawString(dAddress.substring(0, 30), startWidth + 90, startHeight + 655);
                   g.drawString(dAddress.substring(30, dAddress.length()), startWidth + 90, startHeight + 700);
                } else {
                   g.drawString(dAddress, startWidth + 90, startHeight + 655);
                }

                //���Ƽļ��˱���
                g.drawLine(startWidth, startHeight + 828, startWidth + 1198, startHeight +828);
                g.drawLine(startWidth + 80, startHeight + 720, startWidth + 80, startHeight + 828);

                //���üļ��˱�������
                Font fontSender = new Font("����", Font.BOLD, 25);
                g.setFont(fontSender);
                //�ļ��˱����ַ���
                String senderTitleStr = "�ļ���";
                char[] senderTitleArray = senderTitleStr.toCharArray();
                int senderTitleWidth = startWidth + 40;
                int senderTitleHeight = startHeight + 752;
                for (int i = 0; i < senderTitleStr.length(); i++) {
                    g.drawString(String.valueOf(senderTitleArray[i]), senderTitleWidth, senderTitleHeight);
                    senderTitleHeight += 27;
                }


                /*
                 * �ļ�����Ϣ
                 * **/
                String jContact = orderParam.getjContact(); //�ļ�������
                String jTel = orderParam.getjTel(); //�ļ�����ϵ�绰
                String jMobile = orderParam.getjMobile();
                String jCompany = orderParam.getjCompany();
                String jProvince = orderParam.getjProvince();
                String jCity = orderParam.getjCity();
                String jCounty = orderParam.getjCounty();
                String jAddress = orderParam.getjAddress();

                String senderInfo = jContact + " " + jTel + " " + jMobile + " " + jCompany;
                jAddress = jProvince + jCity + jCounty + jAddress;

                //���üļ�����Ϣ����
                Font fontSenderInfo = new Font("����", Font.PLAIN, 30);
                g.setFont(fontSenderInfo);
                g.drawString(senderInfo, startWidth + 90, startHeight + 752);

                //���üļ�����ϸ��ַ����
                Font fontSenderAddress = new Font("����", Font.PLAIN, 30);
                g.setFont(fontSenderAddress);
                if (jAddress.length() > 27) {
                   g.drawString(jAddress.substring(0, 27), startWidth + 90, startHeight + 785);
                   g.drawString(jAddress.substring(27, jAddress.length()), startWidth + 90, startHeight + 817);
                } else {
                   g.drawString(jAddress, startWidth + 90, startHeight + 785);
                }

                //�������ͷ�ʽ����
                g.drawLine(startWidth + 850, startHeight + 720, startWidth + 850, startHeight + 1080);
                //����������������
                Font fontSenTyp = new Font("����", Font.BOLD, 55);
                g.setFont(fontSenTyp);

                //�����ϸ��Ϣ����
                g.drawLine(startWidth, startHeight + 972, startWidth + 850, startHeight + 972);

                //�����ϸ��Ϣ
                Font cellFont = new Font("����", Font.PLAIN, 22);
                g.setFont(cellFont);
                String[][] cellValue1 = {
                        {"���ʽ��",orderParam.getPayMethod()},
                        {"�½��˺ţ�",orderParam.getMonthSettleNo()},
                        {"������������",orderParam.getThridArea()},
                        {"ʵ��������",orderParam.getRealWeight()}
                };
                int cellLineHeight = startHeight + 855;
                for (int i = 0; i < cellValue1.length; i++) {
                    g.drawString(cellValue1[i][0], startWidth + 30, cellLineHeight);
                    g.drawString(cellValue1[i][1], startWidth + 155, cellLineHeight);
                    cellLineHeight += 30;
                }
                String[][] cellValue2 = {
                        {"�Ʒ�������",orderParam.getChargWeight()},
                        {"������ֵ��",orderParam.getDeclarPrice()},
                        {"���۷��ã�",orderParam.getSupportFee()},
                        {"��ʱ���ͣ�",orderParam.getSendTime()}
                };
                cellLineHeight = startHeight + 855;
                for (int i = 0; i < cellValue2.length; i++) {
                    g.drawString(cellValue2[i][0], startWidth + 355, cellLineHeight);
                    g.drawString(cellValue2[i][1], startWidth + 470, cellLineHeight);
                    cellLineHeight += 30;
                }
                String[][] cellValue3 = {
                        {"��װ���ã�",orderParam.getPackFee()},
                        {"�˷ѣ�",orderParam.getFreight()},
                        {"���úϼƣ�",orderParam.getSumFee()}
                };
                cellLineHeight = startHeight + 855;
                for (int i = 0; i < cellValue3.length; i++) {
                    g.drawString(cellValue3[i][0], startWidth + 655, cellLineHeight);
                    g.drawString(cellValue3[i][1], startWidth + 770, cellLineHeight);
                    cellLineHeight += 30;
                }

                //ת��Э��ͻ�
                Font fowardFont = new Font("����", Font.BOLD, 25);
                g.setFont(fowardFont);
                String fowardStr = "ת��Э��ͻ�";
                g.drawString(fowardStr, startWidth + 693, startHeight + 965);

                //�м���
                g.drawLine(startWidth + 80, startHeight + 972, startWidth + 80, startHeight + 1080);
                //�м�������ַ���
                String articleTitleStr = "�м���";
                char[] articleTitleArray = articleTitleStr.toCharArray();
                int articleTitleWidth = startWidth + 40;
                int articleTitleHeight = startHeight + 1005;
                for (int i = 0; i < articleTitleStr.length(); i++) {
                    g.drawString(String.valueOf(articleTitleArray[i]), articleTitleWidth, articleTitleHeight);
                    articleTitleHeight += 31;
                }

                //�ռ�Ա��Ϣ
                g.drawLine(startWidth + 600, startHeight + 972, startWidth + 600, startHeight + 1080);
                Font receDriverFont = new Font("����", Font.PLAIN, 25);
                g.setFont(receDriverFont);
                String[][] receDriverStrs = {
                        {"�ռ�Ա��",orderParam.getReviceDriver()},
                        {"�ļ����ڣ�",orderParam.getSendDate()},
                        {"�ɼ�Ա��",orderParam.getSendDriver()}
                };
                cellLineHeight = startHeight + 1005;
                for (int i = 0; i < receDriverStrs.length; i++) {
                    g.drawString(receDriverStrs[i][0], startWidth + 610, cellLineHeight);
                    g.drawString(receDriverStrs[i][1], startWidth + 730, cellLineHeight);
                    cellLineHeight += 31;
                }
                //ǩ��
                String signStr = "ǩ����";
                g.drawString(signStr, startWidth + 860, startHeight + 860);
                //����
                String monthDay = "��   ��";
                g.drawString(monthDay, startWidth + 1100, startHeight + 1070);

                //ĸ�����ӵ��ָ���
                g.drawLine(startWidth, startHeight + 1080, startWidth + 1198, startHeight + 1080);
                //--------------------------- �ڶ�����Ϣ ----------------------------------//
                g.drawLine(startWidth, startHeight + 1260, startWidth + 1198, startHeight + 1260);
                g.drawLine(startWidth + 300, startHeight + 1080, startWidth + 300, startHeight + 1260);
                //����Logo
                Image sublogoImg = insertImage(LOGO_PATH, LOGO_WIDTH, LOGO_HEIGHT, true);
                g.drawImage(sublogoImg, startWidth + 40, startHeight + 1085, null);
                //����ڶ���logo (�ͷ��绰)
                Image sublogoTelImg = insertImage(LOGO_TEL_PATH, LOGO_TEL_WIDTH, LOGO_TEL_HEIGHT, true);
                g.drawImage(sublogoTelImg, startWidth + 50, startHeight + 1170, null);

                //�����ӵ�����
                Image sfSubBarImg = insertImage(picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg", 0, 0, false);
                g.drawImage(sfSubBarImg, startWidth + 400, startHeight + 1095, null);

                //�ӵ���
                Font subOrderFont = new Font("����", Font.BOLD, 30);
                g.setFont(subOrderFont);
                g.drawString("ĸ����  " + sfBarCodeStr, startWidth + 460, startHeight + 1250);

                //���Ƽļ��˱��� �ӵ�
                g.drawLine(startWidth, startHeight + 1379, startWidth + 1198, startHeight + 1379);
                g.drawLine(startWidth + 80, startHeight + 1260, startWidth + 80, startHeight + 1379);
                //���üļ��˱�������
                Font fontsubSender = new Font("����", Font.BOLD, 30);
                g.setFont(fontsubSender);
                //�ļ��˱����ַ���
                String senderSubTitleStr = "�ļ���";
                char[] senderSubTitleArray = senderSubTitleStr.toCharArray();
                int senderSubTitleWidth = startWidth + 40;
                int senderSubTitleHeight = startHeight + 1295;
                for (int i = 0; i < senderSubTitleStr.length(); i++) {
                    g.drawString(String.valueOf(senderSubTitleArray[i]), senderSubTitleWidth, senderSubTitleHeight);
                    senderSubTitleHeight += 33;
                }
                Font subJInfoFont = new Font("����", Font.PLAIN, 35);
                g.setFont(subJInfoFont);
                g.drawString(senderInfo, startWidth + 110, startHeight + 1295);

                if (jAddress.length() > 30) {
                  g.drawString(jAddress.substring(0, 30), startWidth + 110, startHeight + 1330);
                  g.drawString(jAddress.substring(30, jAddress.length()), startWidth + 110, startHeight + 1365);
                } else {
                  g.drawString(jAddress, startWidth + 110, startHeight + 1330);
                }

                //�����ռ��˱��� �ӵ�
                g.drawLine(startWidth, startHeight + 1499, startWidth + 1198, startHeight + 1499);
                g.drawLine(startWidth + 80, startHeight + 1379, startWidth + 80, startHeight + 1499);
                //�ռ��˱����ַ���
                Font fontsubReveicer = new Font("����", Font.BOLD, 30);
                g.setFont(fontsubReveicer);
                String revicerSubTitleStr = "�ռ���";
                char[] revicerSubTitleArray = revicerSubTitleStr.toCharArray();
                int revicerSubTitleWidth = startWidth + 40;
                int revicerSubTitleHeight = startHeight + 1415;
                for (int i = 0; i < revicerSubTitleStr.length(); i++) {
                    g.drawString(String.valueOf(revicerSubTitleArray[i]), revicerSubTitleWidth, revicerSubTitleHeight);
                    revicerSubTitleHeight += 33;
                }

                Font subDInfoFont = new Font("����", Font.PLAIN, 35);
                g.setFont(subDInfoFont);
                g.drawString(revicerInfo, startWidth + 110, startHeight + 1415);
                if (dAddress.length() > 30) {
                   g.drawString(dAddress.substring(0, 30), startWidth + 110, startHeight + 1450);
                   g.drawString(dAddress.substring(30, dAddress.length()), startWidth + 110, startHeight + 1486);
                } else {
                   g.drawString(dAddress, startWidth + 110, startHeight + 1450);
                }
                g.dispose();
                File sfbarFile = new File(picPath + "SFBarCoding_" + orderParam.getMailNo() + ".jpg");
                if (sfbarFile.exists() && sfbarFile.isFile()) {
                    sfbarFile.delete();
                }
                //���ɶ���ͼƬ
                createImage(picPath + "SfOrderImage_" + orderParam.getMailNo() + ".jpg");
                if (isCompress) {
                    compressImg(picPath + "SfOrderImage_" + orderParam.getMailNo() + ".jpg", imgWidth, imgHeidht);
                }
                logger.info("�������ɳɹ�. " + picPath + "SfOrderImage_" + orderParam.getMailNo() + ".jpg");
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * ˮƽ��תͼ�� ˳ʱ����ת90�ȡ����ҷ�ת
     * @param bufferedimage Ŀ��ͼ��
     * @return
     */
    private static BufferedImage rotate90DX(BufferedImage bi)
    {
        int width = bi.getWidth();
        int height = bi.getHeight();

        BufferedImage biFlip = new BufferedImage(height, width, bi.getType());

        for(int i=0; i<width; i++)
            for(int j=0; j<height; j++)
                biFlip.setRGB(height-1-j, width-1-i, bi.getRGB(i, j));

        return biFlip;
    }


    /**
     * ˮƽ��תͼ�� ��ʱ����ת90�ȡ����ҷ�ת
     * @param bufferedimage Ŀ��ͼ��
     * @return
     */
    private static BufferedImage rotate90SX(BufferedImage bi)
    {
        int width = bi.getWidth();
        int height = bi.getHeight();

        BufferedImage biFlip = new BufferedImage(height, width, bi.getType());

        for(int i=0; i<width; i++)
            for(int j=0; j<height; j++)
                biFlip.setRGB(j, i, bi.getRGB(i, j));

        return biFlip;
    }

    /**
     * ���ݹ涨�ߴ�ѹ��ͼƬ
     * @param imgPath ͼƬ·��
     * @param width ͼƬ����
     * @param height ͼƬ�߶�
     * */
    private static void compressImg(String imgPath, int width, int height){
        /**
         * ��������ͼƬ�ĳߴ�
         * */
        BufferedInputStream bis = null;
        BufferedOutputStream out = null;
        FileOutputStream fis = null;
        try {
            File sfFile = new File(imgPath);
            if (sfFile.isFile() && sfFile.exists()) {
                //��ȡͼƬ
                bis = new BufferedInputStream(new FileInputStream(imgPath));
                //ת����ͼƬ����
                Image bi = ImageIO.read(bis).getScaledInstance(width, height, Image.SCALE_SMOOTH);
                //����ͼƬ�� ����ͼƬ���͸�
                BufferedImage tag = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
                //���Ƹı�ߴ���ͼ
                tag.getGraphics().drawImage(bi, 0, 0,width, height, null);
                //����ͼƬ
                fis = new FileOutputStream(imgPath);
                JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(fis);
                JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);
                //����ѹ��ͼƬ����
                jep.setQuality(3f, true);
                encoder.encode(tag, jep);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null) fis.close();
                if (out != null) out.close();
                if (bis != null) bis.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    //����Ŀ¼
    private static boolean createDir(String destDirName){
        try {
            File file = new File(destDirName);
            if (destDirName.endsWith(File.separator))
                destDirName += File.separator;
            if (file.mkdir())
                return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    //ɾ��Ŀ¼
    public static boolean removeDir(File dir){
        File[] files = dir.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                return removeDir(file);
            } else {
                return file.delete();
            }
        }
        return dir.delete();
    }

    //ɾ��Ŀ¼
    public static boolean deleteMk(String dirPath){
        File dirFile = new File(dirPath);
        if (dirFile.isDirectory()) {
            File[] files = dirFile.listFiles();
            for (int i = 0; i < files.length; i++) {
                files[i].delete();
            }
        }
        return dirFile.delete();
    }

    /**
      * ���ļ�ת��Ϊbyte[]
      * @param filePath �ļ�·��
      * */
     public static byte[] getFileBytes(String filePath){
            byte[] buffer = null;
            FileInputStream fis = null;
            ByteArrayOutputStream bos = null;
            try {
                File file = new File(filePath);
                fis = new FileInputStream(file);
                bos = new ByteArrayOutputStream(1000);
                byte[] b = new byte[1000];
                int n;
                while ((n = fis.read(b)) != -1) {
                    bos.write(b, 0, n);
                }
                buffer = bos.toByteArray();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bos != null) {
                        bos.close();
                    }
                    if (fis != null) {
                        fis.close();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            return buffer;
    }
}