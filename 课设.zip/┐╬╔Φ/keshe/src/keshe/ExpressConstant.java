package keshe;

public class ExpressConstant {

	public static final Integer ORDER_PRINT_TYP_A4 = null;

}
