package keshe;

import java.util.Scanner;

/**
 *
 */
public class App
{
    public static void main( String[] args )
    {
          SfPrintOrderParam param = new SfPrintOrderParam();

          Scanner sc1 = new Scanner(System.in);
          System.out.println("����12λĸ����");
          String str1 = sc1.next();
          param.setMailNo(str1);
          
          param.setEarthCarryFlag("E");
          
          param.setDestCode("0311");
          
          Scanner sc2 = new Scanner(System.in);
          System.out.println("�����ռ���������");
          String str2 = sc2.next();
          param.setdContact(str2);
          
          Scanner sc3 = new Scanner(System.in);
          System.out.println("�����ռ��˵�ַ��");
          String str3 = sc3.next();
          param.setdCompany(str3);
          
          Scanner sc4 = new Scanner(System.in);
          System.out.println("�����ռ����ֻ��ţ�");
          String str4 = sc4.next();
          param.setdMobile(str4);
          
          Scanner sc5 = new Scanner(System.in);
          System.out.println("�����ռ�ʡ�ݣ�");
          String str5 = sc5.next();
          param.setdProvince(str5);
          
          Scanner sc6 = new Scanner(System.in);
          System.out.println("�����ռ��У�");
          String str6 = sc6.next();
          param.setdCity(str6);
          
          Scanner sc7 = new Scanner(System.in);
          System.out.println("�����ռ�����");
          String str7 = sc7.next();
          param.setdCounty(str7);
          
          Scanner sc8 = new Scanner(System.in);
          System.out.println("�����ռ���ϸ��ַ��");
          String str8 = sc8.next();
          param.setdAddress(str8);
          
          Scanner sc9 = new Scanner(System.in);
          System.out.println("����ļ���������");
          String str9 = sc9.next();
          param.setjContact(str9);
          
          Scanner sc10 = new Scanner(System.in);
          System.out.println("����ļ����ֻ��ţ�");
          String str10 = sc10.next();
          param.setjMobile(str10);
          
          Scanner sc11 = new Scanner(System.in);
          System.out.println("����ļ��˵�ַ��");
          String str11 = sc11.next();
          param.setjCompany(str11);
          
          Scanner sc12 = new Scanner(System.in);
          System.out.println("����ļ���ʡ�ݣ�");
          String str12 = sc12.next();
          param.setjProvince(str12);
          
          Scanner sc13 = new Scanner(System.in);
          System.out.println("����ļ����У�");
          String str13 = sc13.next();
          param.setjCity(str13);
          
          Scanner sc14 = new Scanner(System.in);
          System.out.println("����ļ�������");
          String str14 = sc14.next();
          param.setjCounty(str14);
          
          Scanner sc15 = new Scanner(System.in);
          System.out.println("����ļ�����ϸ��ַ��");
          String str15 = sc15.next();
          param.setjCounty(str15);


          SFOrderGenerateUtil.generateOrders(
                    "D:\\COD\\",
                    param,
                    "1",
                    false,
                    600,
                    400);
    }
}